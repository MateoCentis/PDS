import numpy as np
import matplotlib.pyplot as plt
import math
from DFT import DFT
import numpy.fft as fft
import scipy.signal as spy
pi = math.pi
#multiplicar por z^-n es igual a retardar a n en el tiempo


#1. H(z)=Y(z)/X(z)=z^2/(z^2-1/2*z+1/4)
def H1(z):
    return (z**2)/(z**2-(1/2)*z+1/4)
#2. H(z)=Y(z)/X(z)=z/(z^2-z-1)
def H2(z):
    return (z)/(z**2-z-1)
#3. h(Z)=Y(z)/X(z)=7z^2/(z^2-2z+6)
def H3(z):
    return (7*(z**2))/(z**2-2*z+6)
#4. 
def H4(z):
    y = np.zeros(len(z))
    for i in np.arange(0,len(z),1):
        for j in np.arange(0,7,1):
            y[i] += 2**(-j) *z[i-j]
    return y

#H(z)->H[k]-> h[n]
#Si el sistema es FIR siempre se puede porque puedo discretizar en esa cantidad de términos 
    #el omega de fourier

fm = 10000 
N = 512
# frecs = np.arange(-fm//2, fm//2, fm/N)  
frecs = np.arange(0,fm,fm/N)
omega = np.arange(0, 2*pi, 2*pi/N)    #omega de 0 a 2pi, con salto N
ejw = np.exp(1j * omega)    #e^jw
#en vez de pasarle z le pasamos e^-njw

#1. bien

fig1 = plt.figure()
respuesta1 = fft.fftshift(np.abs(H1(ejw))) #Calculo de respuesta, tomo amplitud y lo desplazo
plt.title('Respuesta sistema 1')
plt.ylabel('|H1(Z)|')
plt.xlabel('frecuencias [hz]')
plt.plot(frecs,respuesta1)
respuesta1Freqz = fft.fftshift(spy.freqz([1],[1,-1/2,1/4],whole=True)[1])
fig1F = plt.figure()
plt.plot(frecs,respuesta1Freqz) 
plt.ylabel('|H1(Z)|')
plt.xlabel('frecuencias [hz]')
plt.title('Respuesta sistema 1 - Freqz')


#2. bien
fig2 = plt.figure()
respuesta2 = fft.fftshift(np.abs(H2(ejw)))
plt.title('Respuesta sistema 2')
plt.ylabel('|H2(Z)|')
plt.xlabel('frecuencias [hz]')
plt.plot(frecs,respuesta2)
respuesta2Freqz = np.abs(fft.fftshift(spy.freqz([0,1],[1,-1,-1],whole=True)[1]))
fig2F = plt.figure()
plt.plot(frecs,respuesta2Freqz) 
plt.ylabel('|H2(Z)|')
plt.xlabel('frecuencias [hz]')
plt.title('Respuesta sistema 2 - Freqz')


#3. bien
fig3 = plt.figure()
respuesta3 = fft.fftshift(np.abs(H3(ejw)))
plt.title('Respuesta sistema 3')
plt.ylabel('|H3(Z)|')
plt.xlabel('frecuencias [hz]')
plt.plot(frecs,respuesta3)
respuesta3Freqz = np.abs(fft.fftshift(spy.freqz([7],[1,-2,6],whole=True)[1]))
fig3F = plt.figure()
plt.plot(frecs,respuesta3Freqz) 
plt.ylabel('|H3(Z)|')
plt.xlabel('frecuencias [hz]')
plt.title('Respuesta sistema 3 - Freqz')


# #4.
# respuesta4 = fft.fftshift(np.abs(H4(ejw)))
# plt.plot(frecs,respuesta4)
plt.show()